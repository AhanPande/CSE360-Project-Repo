package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
//Andrew's Imports
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class SceneController  {

	@FXML Button docBtn;
	@FXML Button nurseBtn;
	@FXML Button btnScene1;
	@FXML Button btnScene2;
	@FXML Button btnScene4;
	@FXML Button loginBtn;
	@FXML Button signOutBtn;
	@FXML Button vitalButton;
	@FXML Button messagePatient;
	
	ArrayList<PatientInfo> allPatients;

	public SceneController(){
		 allPatients = new ArrayList<PatientInfo>();
	}
	
	public void handleBtn1() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("PatientLogin.fxml"));
		Stage window = (Stage) btnScene1.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void handleBtn2() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		Stage window = (Stage) btnScene2.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void docHandleBtn()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("DoctorLogin.fxml"));
		Stage window = (Stage) docBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void NurseHandleBtn()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseLogin.fxml"));
		Stage window = (Stage) nurseBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void NurseHandleLogin()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
		Stage window = (Stage) loginBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void NurseHandleLogout()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		Stage window = (Stage) signOutBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	public void DoctorHandleLogin()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("DoctorAfterLogin.fxml"));
		Stage window = (Stage) loginBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void newPatient()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseNewPatient.fxml"));
		Stage window = (Stage) vitalButton.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	@FXML TextField PatientInformationFirstName;
	@FXML TextArea PatientInformationText;
	@FXML Button ViewPatientInformation;
	@FXML TextArea NurseUnreadMessages;
	
	public void NurseGetPatientInformation(ActionEvent event) throws FileNotFoundException {
		String FirstName = PatientInformationFirstName.getText();
		
		int count = 0;
		ArrayList<String> commands = new ArrayList<String>();
		Scanner scan = new Scanner(new File("PatientVitals.txt"));
		String line = null;
		while (scan.hasNext()) {
			line = scan.nextLine();
			commands.add(line);
		}
		for(int i=0; i< commands.size(); i++) {
			if(commands.get(i).contains(FirstName)) {
				count = i;
			}
		}
	        
		ArrayList<String> newCommands = new ArrayList<String>(); // View Info
		newCommands = returnCommand(commands.get(count)); // View Info
		PatientInformationText.setText("Name: " + newCommands.get(0) + " " + newCommands.get(1) + "\n" +
										"Weight: " + newCommands.get(2) + "\n" +
										"Height: " + newCommands.get(3)+ "\n" +
										"Body Temp: " + newCommands.get(4) + "\n" +
										"Blood Pressure: " + newCommands.get(5) );

		Boolean flag = true;
		ArrayList<String> messages = new ArrayList<String>();
		int count2 = 0;
		//File tempFile = new File("MessageDoctorNurse.txt");
		//flag = tempFile.exists();

		if(flag == true) {
			Scanner scan1 = new Scanner(new File("MessageDoctorNurse.txt"));
			String line1 = null;
			while (scan1.hasNext()) {
				line1 = scan1.nextLine();
				messages.add(line1);
			}
			for(int i = 0; i < messages.size(); i++) {
				if(messages.get(i).contains(FirstName)) {
					count2 = i;
				}
			}
		}

		if(flag == false) {
			ViewMessageField.setText("No Messages");
		} else {
			ArrayList<String> newMessageCommand; //View Messages
			newMessageCommand = returnCommand(messages.get(count2)); //View Messages
			NurseUnreadMessages.setText("Unread Messages: " + "\n" + newMessageCommand.get(2));
		}
	}

	@FXML Button DoctorViewPatientInformation;
	@FXML TextArea DoctorUnreadMessages;
	public void DoctorGetPatientInformation(ActionEvent event) throws FileNotFoundException {
		String FirstName = PatientInformationFirstName.getText();

		int count = 0;
		ArrayList<String> commands = new ArrayList<String>();
		Scanner scan = new Scanner(new File("PatientVitals.txt"));
		String line = null;
		while (scan.hasNext()) {
			line = scan.nextLine();
			commands.add(line);
		}
		for(int i=0; i< commands.size(); i++) {
			if(commands.get(i).contains(FirstName)) {
				count = i;
			}
		}

		ArrayList<String> newCommands = new ArrayList<String>(); // View Info
		newCommands = returnCommand(commands.get(count)); // View Info
		PatientInformationText.setText("Name: " + newCommands.get(0) + " " + newCommands.get(1) + "\n" +
				"Weight: " + newCommands.get(2) + "\n" +
				"Height: " + newCommands.get(3)+ "\n" +
				"Body Temp: " + newCommands.get(4) + "\n" +
				"Blood Pressure: " + newCommands.get(5) );

		Boolean flag = true;
		ArrayList<String> messages = new ArrayList<String>();
		int count2 = 0;
		//File tempFile = new File("MessageDoctorNurse.txt");
		//flag = tempFile.exists();

		if(flag == true) {
			Scanner scan1 = new Scanner(new File("MessageDoctorNurse.txt"));
			String line1 = null;
			while (scan1.hasNext()) {
				line1 = scan1.nextLine();
				messages.add(line1);
			}
			for(int i = 0; i < messages.size(); i++) {
				if(messages.get(i).contains(FirstName)) {
					count2 = i;
				}
			}
		}

		if(flag == false) {
			ViewMessageField.setText("No Messages");
		} else {
			ArrayList<String> newMessageCommand; //View Messages
			newMessageCommand = returnCommand(messages.get(count2)); //View Messages
			DoctorUnreadMessages.setText("Unread Messages: " + "\n" + newMessageCommand.get(2));
		}
	}
	
	@FXML TextField PatientVitalFirstName;
	@FXML TextField PatientVitalLastName;
	@FXML TextField PatientVitalWeight;
	@FXML TextField PatientVitaHeight;
	@FXML TextField PatientVitalBodyTemp;
	@FXML TextField PatientVitalBloodPressure;
	@FXML Button PatientVitalSave;
	@FXML Button PatientVitalGoBack;
	
	public void savePatientVitals(ActionEvent event)throws IOException
	{
		PatientVitalSave.setOnAction(e -> {
			
			String FirstName = PatientVitalFirstName.getText();
			String LastName = PatientVitalLastName.getText();
			String Weight = PatientVitalWeight.getText();
			String Height = PatientVitaHeight.getText();
			String Temp = PatientVitalBodyTemp.getText();
			String Blood = PatientVitalBloodPressure.getText();
	
	         try {
	        	 FileWriter myObj = new FileWriter("PatientVitals.txt", true);
	             myObj.write(FirstName +  ",," + LastName + ",," + Weight +  ",," + Height +  ",," + Temp  + ",," + Blood +   "\n");
	             myObj.close();
	             System.out.println("Successfully wrote to the file.");
	             
	           } catch (IOException e1) {
	             System.out.println("An error occurred.");
	             e1.printStackTrace();
	           }        
		});
	}

	public void PatientVitalGoBack() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
		Stage window = (Stage) PatientVitalGoBack.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	@FXML Button docBack;
	public void DoctorGoBack() throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("DoctorAfterLogin.fxml"));
		Stage window = (Stage) docBack.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
		
	}
	
	@FXML Button patientInfo;
	public void PatientInfo()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NursePatientInformation.fxml"));
		Stage window = (Stage) patientInfo.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void PatientInfo2()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("DoctorPatientInformation.fxml"));
		Stage window = (Stage) patientInfo.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	@FXML Button message;
	public void MessageButton()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseMessagePatient.fxml"));
		Stage window = (Stage) message.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	public void MessageButton2()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("DoctorMessagePatient.fxml"));
		Stage window = (Stage) message.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	@FXML TextField MessagePatientTo;
	@FXML TextArea MessagePatient;
	@FXML Button SendPatientMessage;
	@FXML Label confirmMessage;
	@FXML Button BackMessagePatient;
	public void MessagePatient(ActionEvent Event) {
		SendPatientMessage.setOnAction(e -> {
			String to = MessagePatientTo.getText();
			String MessageToPatient = MessagePatient.getText();
	         try {
	         	FileWriter myObj = new FileWriter("DoctorNurseMessages.txt", true);
	         	myObj.write(to +  ",," + MessageToPatient +  "\n");
	         	myObj.close();
	         	confirmMessage.setText("Message Succesfully Sent");
	         	System.out.println("Successfully wrote to the file.");
	         } catch (IOException e1) {
	         	System.out.println("An error occurred.");
	         	e1.printStackTrace();
	         }
		});
	}
	
	@FXML Button LeaveNurseMessage;
	public void LeaveMessageNurse()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
		Stage window = (Stage)LeaveNurseMessage.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	@FXML Button patientInfoGoBack;
	public void PatientInfoGoBack()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
		Stage window = (Stage) patientInfoGoBack.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	@FXML Button patientInfoSend;
	public void PatientInfoSendMessage()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
		Stage window = (Stage) patientInfoSend.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	@FXML Button appointmentInfo;
	public void DocAppointmentInformation(ActionEvent event)throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("DocAppointmentInformation.fxml"));
		Stage window = (Stage) appointmentInfo.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));

	}

	@FXML TextArea DoctorNotes;
	@FXML Button saveNotesBtn;

	//	save any added notes by doctor
	public void saveDoctorNotes(ActionEvent event)throws IOException {
		saveNotesBtn.setOnAction(e -> {
			String notes = DoctorNotes.getText();
			String firstName = PatientInformationFirstName.getText();

			try {
				FileWriter myObj = new FileWriter("DoctorNotes.txt", true);
				myObj.write(firstName + '\n' + notes + '\n');
				myObj.close();
				System.out.println("Successfully wrote to the file.");
			} catch (IOException e1) {
				System.out.println("An error occurred.");
				e1.printStackTrace();
			}
		});
	}

	//	view most recent appointment notes
	@FXML Button ViewRecentAppointment;
	public void getRecentAppointmentNotes(ActionEvent event) throws IOException {
		String FirstName = PatientInformationFirstName.getText();
		int count = 0;
		ArrayList<String> commands = new ArrayList<>();
		Scanner scan = new Scanner(new File("DoctorNotes.txt"));
		String line;
		while (scan.hasNext()) {
			line = scan.nextLine();
			commands.add(line);
		}
		for (int i = 0; i < commands.size(); i++) {
			if (commands.get(i).contains(FirstName)) {
				count = i;
			}
		}
		DoctorNotes.setText(commands.get(count + 1));
	}
//	go to prescription form
	@FXML Button prescriptionBtn;
	public void newPrescription(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("PrescriptionForm.fxml"));
		Stage window = (Stage) prescriptionBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	// submit prescription
	@FXML Button SubmitPrescriptionBtn;
	public void submitPrescription(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("AfterPrescriptionSubmit.fxml"));
		Stage window = (Stage) SubmitPrescriptionBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	// return to appointment information for Doctor
	@FXML Button returnToPatientBtn;
	public void ReturnToPatient(ActionEvent event) throws  IOException {
		Parent root = FXMLLoader.load(getClass().getResource("DocAppointmentInformation.fxml"));
		Stage window = (Stage) returnToPatientBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	@FXML Button patientLoginBtn;
	@FXML Label usernameLabel;
	@FXML TextField usernameTF;
	public void LoginwithPatient(ActionEvent event)throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("PatientAfterLogin.fxml"));
		Stage window = (Stage) patientLoginBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

//	View Patient Visits
	@FXML Button patientVisitsBtn;
	public void patientVisitHistory()throws IOException
	{
		String FirstName = EnterFirstName.getText();
		int count = 0;
		ArrayList<String> commands = new ArrayList<>();
		Scanner scan = new Scanner(new File("DoctorNotes.txt"));
		String line;
		while (scan.hasNext()) {
			line = scan.nextLine();
			commands.add(line);
		}
		for (int i = 0; i < commands.size(); i++) {
			if (commands.get(i).contains(FirstName)) {
				count = i;
			}
		}
		ViewMessageField.setText("Most recent notes from doctor: " + '\n' + commands.get(count + 1));
	}
	
// 	Send and View Messages
	@FXML Button patientMessageBtn;
	public void patientMessageHistory()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("PatientSendMessage.fxml"));
		Stage window = (Stage) patientMessageBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
//	Back to Main Screen
	@FXML Button patientBackBtn;
	public void patientGoBack()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("PatientAfterLogin.fxml"));
		Stage window = (Stage) patientBackBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	@FXML Button patientBackLoginBtn;
	public void patientBackLogin()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("PatientLogin.fxml"));
		Stage window = (Stage) patientBackLoginBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}
	
	@FXML Button createAccountPageBtn;
	//button used get text for account creation
	@FXML Button createAccountBtn;
	@FXML Text text;
	@FXML TextField newUserID;
	@FXML TextField newPassword;
	@FXML TextField dateOfBirth;
	@FXML TextField patientPhoneNumber;
	@FXML TextField FirstName;
	@FXML TextField LastName;
	@FXML Label nameLabel;
	@FXML Label dobLabel;
	@FXML Label phoneLabel;

	public void patientCreateAccountPage()throws IOException
	{
		Parent root = FXMLLoader.load(getClass().getResource("PatientCreateAccountScreen.fxml"));
		Stage window = (Stage)createAccountPageBtn.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	}

	Queue<String> q = new LinkedList<>();
	@FXML Label ViewInfoName;
	public void patientAccountCreation(ActionEvent event)throws IOException
	{
		createAccountBtn.setOnAction(e -> {
			 String id = newUserID.getText();
	         String password = newPassword.getText();
	         String dob = dateOfBirth.getText();
	         String patientPhoneNum = patientPhoneNumber.getText();
	         String fn = FirstName.getText();
	         String ln = LastName.getText();
	         q.add(fn);
	         PatientInfo patient = new PatientInfo(fn,ln,dob,patientPhoneNum,id, password);
	         allPatients.add(patient);
	         
	         try {
	        	 FileWriter myObj = new FileWriter("Users.txt", true);
	             myObj.write(id +  ",," + password + ",," + dob + ",," + patientPhoneNum + ",," + fn + ",," + ln + "\n");
	             myObj.close();
	        
	             System.out.println("Successfully wrote to the file.");
	         } catch (IOException e1) {
				 System.out.println("An error occurred.");
				 e1.printStackTrace();
	         }
	      });
	}

	@FXML Button NextPage;
	public void nextPage(ActionEvent event) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("PatientAfterLogin.fxml"));
		Stage window = (Stage)NextPage.getScene().getWindow();
		window.setScene(new Scene(root, 750, 500));
	
	}

	@FXML Button ViewInfo;
	@FXML Label ViewDOB;
	@FXML Label ViewPhone;
	@FXML TextField EnterFirstName;
	@FXML TextArea ViewMessageField;

	public void ViewInfoButton(ActionEvent event) throws IOException{
		Boolean flag = true;
		ArrayList<String> commands = new ArrayList<String>();
		int count = 0;
		String name = EnterFirstName.getText();
		System.out.print(name);
		Scanner scan = new Scanner(new File("Users.txt"));
		String line = null;
		while (scan.hasNext()) {
			line = scan.nextLine();
			commands.add(line);
		}
		for(int i=0; i< commands.size(); i++) {
			if(commands.get(i).contains(name)) {
				count = i;
			}
		}
	        
		ArrayList<String> messages = new ArrayList<String>();
		int count2 = 0;
		File tempFile = new File("DoctorNurseMessages.txt");
		flag = tempFile.exists();
	        
		if(flag == true) {
	        Scanner scan1 = new Scanner(new File("DoctorNurseMessages.txt"));
	        String line1 = null;
	        while (scan1.hasNext()) {
	            line1 = scan1.nextLine();
	            messages.add(line1);
	        }
	        
	        for(int i = 0; i < messages.size(); i++) {
	        	if(messages.get(i).contains(name)) {
	        		count2 = i;
	        	}
	        }
		}
		ArrayList<String> newCommands = new ArrayList<String>(); // View Info
		newCommands = returnCommand(commands.get(count)); // View Info
		ViewInfoName.setText("Name: " + newCommands.get(4) + " " + newCommands.get(5));
		ViewDOB.setText("Birthday: " +newCommands.get(2) );
		ViewPhone.setText("Phone Number: " + newCommands.get(3));
	        
		if(flag == false) {
			ViewMessageField.setText("No Messages");
		} else {
			ArrayList<String> newMessageCommand = new ArrayList<String>(); //View Messages
			newMessageCommand = returnCommand(messages.get(count2)); //View Messages
			ViewMessageField.setText("Unread Messages: " + "\n" + newMessageCommand.get(1));
		}
	}
	
	public ArrayList<String> returnCommand(String s){
		String[] values = s.split(",,");
		ArrayList<String> newCommands = new ArrayList<String>(Arrays.asList(values));
		return newCommands;
	}

	@FXML Button MessageButton;
	public void MessagePage(ActionEvent event) throws IOException{
	     Parent root = FXMLLoader.load(getClass().getResource("PatientSendMessage.fxml"));
		 Stage window = (Stage)MessageButton.getScene().getWindow();
		 window.setScene(new Scene(root, 750, 500));
	}

	@FXML TextField From;
	@FXML TextField PhoneNumber;
	@FXML TextArea Message;
	@FXML Button SendMessage;
	@FXML Label SentLabel;
	public void SumbitMessage(ActionEvent event) {
		SendMessage.setOnAction(e -> {
			System.out.print("Got here");
			String from = From.getText();
			String pn = PhoneNumber.getText();
			String message = Message.getText();
	         try {
	        	 FileWriter myObj = new FileWriter("MessageDoctorNurse.txt", true);
	             myObj.write(from +  ",," + pn + ",," + message + "\n");
	             myObj.close();
	        
	             SentLabel.setText("Message Succesfully Sent");
	             System.out.println("Successfully wrote to the file.");
	             
	           } catch (IOException e1) {
	             System.out.println("An error occurred.");
	             e1.printStackTrace();
	           }        
	      });
	}
}