package application;

import java.io.IOException;
import java.util.EventObject;

import javax.print.DocFlavor.URL;
import javax.swing.Action;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SceneController {
	
	@FXML
	Button nurseBtn;
	
	@FXML
	Button btnScene1;
	
	@FXML
	Button btnScene2;
	
	@FXML
	Button btnScene4;
	
	@FXML
	Button loginBtn;
	
	@FXML
	Button signOutBtn;
	
	@FXML
	Button vitalButton;
	
	@FXML
	Button messagePatient;
	
	@FXML
	Button cancel;
	
	@FXML
	Button save;
	
	public void handleBtn1() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
		 
		 Stage window = (Stage) btnScene1.getScene().getWindow();
		 window.setScene(new Scene(root, 750, 500));
		
	}
	
	public void handleBtn2() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		 
		 Stage window = (Stage) btnScene2.getScene().getWindow();
		 window.setScene(new Scene(root, 750, 500));
	
	}
	
	public void NurseHandleBtn()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseLogin.fxml"));
			 Stage window = (Stage) nurseBtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
			 
			 
	}
	
	public void NurseHandleLogin()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
			 Stage window = (Stage) loginBtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
			 
			 
	}
	
	public void NurseHandleLogout()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
			 Stage window = (Stage) signOutBtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
			 
	}
	
	
	public void newPatient()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseNewPatient.fxml"));
			 Stage window = (Stage) vitalButton.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	public void cancelPatientVitals()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
			 Stage window = (Stage) cancel.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	public void savePatientVitals()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
			 Stage window = (Stage) cancel.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	
	@FXML
	Button patientInfo;
	public void PatientInfo()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("PatientInformation.fxml"));
			 Stage window = (Stage) patientInfo.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	

	@FXML
	Button message;
	
	public void MessageButton()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("MessagePatient.fxml"));
			 Stage window = (Stage) message.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	@FXML
	Button patientInfoGoBack;
	public void PatientInfoGoBack()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
			 Stage window = (Stage) patientInfoGoBack.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	
	
	@FXML
	Button patientInfoSend;
	public void PatientInfoSendMessage()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("NurseAfterLogin.fxml"));
			 Stage window = (Stage) patientInfoSend.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}


//DOCTOR Buttons and Methods Unique to the Doctor
//---------------------------------------------------------------------------------------------------------------------------------
	
	@FXML
	Button DoctorBtn; //Used to select doctor in the login
	
	@FXML
	Button Next; //Used to continue or go to next
	
	@FXML
	Button Back; //Used to go back
	
	@FXML
	Button Enter; //Used to enter information
	
	@FXML
	Button ViewAppointmentbtn; //Used to select View Appointment
	
	@FXML
	Button ViewPatientInfobtn; //Used to select Patient Info
	
	@FXML
	Button ViewAppointmentInfobtn;
	
	//Selects the Doctor in the login options
	public void DoctorLoginSelect()throws IOException
	{
		  Parent root = FXMLLoader.load(getClass().getResource("doctoLogin.fxml"));
			 Stage window = (Stage) DoctorBtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	//When on the doctor Login Window and select Login sends you to doctor portal using the loginbtn button 
	public void DoctorLogin()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorPortal.fxml"));
			 Stage window = (Stage) loginBtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	//Goes Back to portal using the Back button
	public void DoctorBacktoPortal()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorPortal.fxml"));
			 Stage window = (Stage) Back.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	//When in doctor portal goes to View Appointments scene using the ViewAppointmentsbtn button
	public void DoctorViewAppointment()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorViewAppointments.fxml"));
			 Stage window = (Stage) ViewAppointmentbtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	//When in doctor portal goes to Patient Information scene using the ViewPatientInfobtn button
	public void DoctorPatientInfo()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorPatientInformation.fxml"));
			 Stage window = (Stage) ViewPatientInfobtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	//When on the patient select scene on view Patient Info goes to the next scene with the Next button
	public void DoctorPatientInfoNext()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorPatientInformationNext.fxml"));
			 Stage window = (Stage) Next.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	public void DoctorAppointmentInfo()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorAppointmentInformation.fxml"));
			 Stage window = (Stage) ViewAppointmentInfobtn.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
	public void DoctorAppointmentInfoNext()throws IOException
	{
		  	Parent root = FXMLLoader.load(getClass().getResource("DoctorAppointmentInformationNext.fxml"));
			 Stage window = (Stage) Next.getScene().getWindow();
			 window.setScene(new Scene(root, 750, 500));
	}
	
}
