package application;

public class PatientInfo {
	
	public String firstName;
	public String lastName;
	public String birthday;
	public String phoneNumber;
	public String username;
	public String password;
	
	
	public PatientInfo(String firstName, String lastName, String birthday, String phoneNumber, String username, String password) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthday = birthday;
		this.phoneNumber = phoneNumber;
		this.username = username;
		this.password = password;
	}
	
	public String toString() {
		return this.firstName;
	}
	
	public String getFirstName() {
		return this.firstName;
	}
	
	public String getLastName() {
		return this.lastName;
	}
	
	public String getBirthday() {
		return this.birthday;
	}
	
	
	

}
